> Why do I have a folder named ".expo" in my project?

The ".expo" folder is created when an Expo project is started using "expo start" command.

> What does the "packager-info.json" file contain?

The "packager-info.json" file contains port numbers and process PIDs that are used to serve the application to the mobile device/simulator.

> What does the "settings.json" file contain?

The "settings.json" file contains the server configuration that is used to serve the application manifest.

> Should I commit the ".expo" folder?

No, you should not share the ".expo" folder. It does not contain any information that is relevant for other developers working on the project, it is specific to your machine.

Upon project creation, the ".expo" folder is already added to your ".gitignore" file.


Le principal avantage quand vous optez pour le développement natif, qu’il s’agisse d’Android ou iOS, est la stabilité de votre application mobile.
 Les applications natives ont en effet directement accès aux fonctions natives du téléphone de l’utilisateur. 
Elles sont conçues pour avoir un accès fluide aux éléments natifs tels que l’appareil photo, les contacts, l’accéléromètre, la géolocalisation et bien d’autres.
React Native offre une expérience de type natif en permettant aux développeurs de créer des applications à l'aide de JavaScript et de modules natifs.
 React Native est plus rapide et offre une apparence native sur les plates-formes Android et iOS.
 JavaScript est utilisé pour interagir avec les API natives et les composants natifs, ce qui rend le développement d'applications plus rapide et efficace.
 C'est une excellente option si vous débutez et que vous souhaitez augmenter votre base d'utilisateurs avec des ressources et un budget limités.
Kotlin pour son application Android
Kotlin est un langage de programmation édité par JetBrains. Cet éditeur est également le créateur de IntelliJ, la base d’Android Studio.
 Kotlin a été officialisé par Google, lors de I/O 2017, comme étant le second langage de programmation pour les applications natives Android, après Java.